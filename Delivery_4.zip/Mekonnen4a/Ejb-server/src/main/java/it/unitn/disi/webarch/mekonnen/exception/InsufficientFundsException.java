package it.unitn.disi.webarch.mekonnen.exception;

public class InsufficientFundsException extends Exception {

    public InsufficientFundsException(String mess) {
        super(mess);
    }
}

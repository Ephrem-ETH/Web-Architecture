package it.unitn.disi.webarch.mekonnen.ejb;

/**
 *
 * @author ephrem
 */
public interface Calculator {

    public float calculateInterest(long money);
}

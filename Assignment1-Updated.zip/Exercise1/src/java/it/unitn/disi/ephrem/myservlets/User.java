package it.unitn.disi.ephrem.myservlets;

import java.util.LinkedList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ephrem
 */
public class User {

    private int id;
    private String name;
    private String favoriteSoccer;
    static List<User> users = new LinkedList<User>();

    public User(String name, String favoriteSoccer) {
        this.id++;
        this.name = name;
        this.favoriteSoccer = favoriteSoccer;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getFavoriteSoccer() {
        return favoriteSoccer;
    }

    public static void addUser(User user) {

        users.add(user);
    }

    public static void removeUser(String name) {
        users.remove(name);
    }

    public static List<User> getUsers() {
        return users;
    }

}
